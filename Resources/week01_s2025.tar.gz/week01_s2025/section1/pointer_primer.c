#include <stdio.h>

struct foo {
  int i;
  float f;
  char *s;
};

/* f is a copy (pass by value) of the struct passed from the caller! */
//void foo_init(struct foo f, int i, float g)
// Need to pass by address
void foo_init(struct foo *f, int i, float g)
{
  f->i = i;
  f->f = g;

  printf("f.i: %d, f.f: %f\n", f->i, f->f);
}

int main(int argc, char *argv[])
{
  struct foo f;

  // To get a pointer from an instance, take the instance's address
  // using the address operator, &
  foo_init(&f, 42, 3.1415926);

  printf("f.i: %d, f.f: %f\n", f.i, f.f);
  
  return 0;
}
