#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int i, j;
  int val;
  
  if (argc == 1) {
    printf("Hello World!\n");
  } else {
    for (i = 1; i < argc; i++) {
      if (isdigit(argv[i][0])) {
        val = atoi(argv[i]);
        printf("%d\n", val);
      } else {
        printf("Hello ");
//    for (j = 0; argv[i][j] != '\0'; j++) { // Iterate through the string until
                                             // we find the NULL byte ('\0')
        for (j = 0; argv[i][j]; j++) { // More idiomatic C.  Every expression
          printf("%c", argv[i][j]);    // has a truth value.
        }
        printf("!\n");
      }
    }
  }
  
  return 0;
}
