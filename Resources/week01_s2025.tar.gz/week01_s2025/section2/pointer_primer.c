#include <stdio.h>

struct foo {
  int i;
  float f;
  char *s;
};

/* Incorrect!  Pass by value only changes the values in the copy!
void populate_foo(struct foo f)
{
  f.i = 42;
  f.f = 3.1415;

  printf("i = %d, f = %f\n", f.i, f.f);
}
*/

/* Using a pointer to f, we are now passing by address!  Rather than a copy
 * of f, we now have the address of f!
 */
void populate_foo(struct foo *f)
{
  f->i = 42;
  f->f = 3.1415;

  printf("i = %d, f = %f\n", f->i, f->f);
}

int main(int argc, char *argv[])
{
  struct foo f;

  f.i = 0;
  f.f = 0;

  printf("i = %d, f = %f\n", f.i, f.f);

  /* & is the address operator.  &f is the address of f (a pointer) */
  populate_foo(&f);

  printf("i = %d, f = %f\n", f.i, f.f);

  return 0;
}
