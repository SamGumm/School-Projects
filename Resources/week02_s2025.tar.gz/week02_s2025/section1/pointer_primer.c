#include <stdio.h>
#include <stdlib.h>


struct foo {
  int i;
  float f;
};

/* f is a copy (pass by value) of the struct passed from the caller! */
//void foo_init(struct foo f, int i, float g)
// Need to pass by address
void foo_init(struct foo *f, int i, float g)
{
  f->i = i;
  f->f = g;

  printf("f.i: %d, f.f: %f\n", f->i, f->f);
}

/* The opposite of the address operator, &, is the dereference operator, *.
 * Given a pointer, using the dereference operator will get us to the
 * referenced data.
 */


/* This function swaps the addresses of i and j!  But those are copies */
/* We say that C has pass by value and pass by address, but that's not *
 * technically true.  Pass by address is actually passing addresses by *
 * value!                                                              */
/*
void swap(int *i, int *j)
{
  int *tmp;

  printf("%d %d\n", *i, *j);
  
  tmp = i;
  i = j;
  j = tmp;

  printf("%d %d\n", *i, *j);
}
*/

void swap(int *i, int *j)
{
  int tmp;

  printf("%d %d\n", *i, *j);

  tmp = *i;
  *i = *j;
  *j = tmp;

  printf("%d %d\n", *i, *j);
}

int main(int argc, char *argv[])
{
  struct foo f;
  int x, y;
  int *p;
  int i;
  
  x = 0;
  y = 1;


  p = &x;
  
  printf("%d %d\n", x, y);
  swap(&x, &y);
  printf("%d %d\n", x, y);
  
  printf("%d\n", *p);

  p = malloc(sizeof (*p));

  *p = 9;

  printf("%d\n", *p);


  free(p);

  //  Error to follow pointers to freed storage
  //  printf("%d\n", *p);

  // Malloc an array of 10 ints
  p = malloc(10 * sizeof (*p));

  for (i = 0; i < 10; i++) {
    // Array syntax works on pointers.
    p[i] = i;
  }

  for (i = 0; i < 10; i++) {
    // But we can also use pointer syntax!
    // "Pointer arithmetic": The compiler multiplies i * sizeof (*p)
    // for us.  Do not explicitly multiply.
    printf("%d\n", *(p + i));
  }

  free(p);
  // Return p to heap; don't attempt to follow again.

  // To get a pointer from an instance, take the instance's address
  // using the address operator, &
  foo_init(&f, 42, 3.1415926);

  printf("f.i: %d, f.f: %f\n", f.i, f.f);
  
  return 0;
}
