#include <stdlib.h>

#include "stack.h"

/*
struct stack s;
stack_init(&s);

struct stack *sp;
sp = malloc(sizeof (*sp));
stack_init(sp);
*/

int stack_init(struct stack *s)
{
  s->top = NULL;
  s->size = 0;

  return 0;
}

int stack_destroy(struct stack *s)
{
  /* This is valid, but not performant.
  int tmp;
  
  while (!stack_pop(s, &tmp))
    ;

  return 0;
  */

  struct stack_node *tmp;

  while ((tmp = s->top)) {
    s->top = s->top->next;
    free(tmp);
  }

  s->size = 0;

  return 0;
}

int stack_push(struct stack *s, int value)
{
  struct stack_node *tmp;

  if (!(tmp = malloc(sizeof (*tmp)))) {
    // Returned NULL.  Malloc failed.
    return -1;
  }
  
  tmp->next = s->top;
  s->top = tmp;
  tmp->data = value;

  s->size++;

  return 0; // Success
}

int stack_pop(struct stack *s, int *value)
{
  struct stack_node *tmp;
  
  if (!s->size) {
    return -1;
  }

  *value = s->top->data;
  tmp = s->top;
  s->top = s->top->next;

  free(tmp);

  s->size--;

  return 0;
}

int stack_top(struct stack *s, int *value)
{
  if (!s->top) {
    return -1;
  }

  *value = s->top->data;

  return 0;
}

int stack_is_empty(struct stack *s)
{
  return !s->size;
}

int stack_size(struct stack *s)
{
  return s->size;
}
