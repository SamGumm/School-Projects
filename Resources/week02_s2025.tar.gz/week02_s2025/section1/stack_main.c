#include <stdio.h>

#include "stack.h"

int main(int argc, char *argv[])
{
  struct stack s;
  int i, j;
  
  stack_init(&s);  // (Theoretically) this can fail, so we *should*
                   // check the return value!

  for (i = 0; i < 10; i++) {
    stack_push(&s, i);
  }

  stack_top(&s, &j);
  printf("is empty? %d, size: %d, top: %d\n",
         stack_is_empty(&s), stack_size(&s), j);

  while (!stack_pop(&s, &j)) {
    printf("%d\n", j);
  }

  printf("is empty? %d, size: %d\n",
         stack_is_empty(&s), stack_size(&s));

  stack_destroy(&s);

  return 0;
}
