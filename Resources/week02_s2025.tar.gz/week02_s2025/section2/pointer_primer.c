#include <stdio.h>
#include <stdlib.h>

struct foo {
  int i;
  float f;
};

/* Incorrect!  Pass by value only changes the values in the copy!
void populate_foo(struct foo f)
{
  f.i = 42;
  f.f = 3.1415;

  printf("i = %d, f = %f\n", f.i, f.f);
}
*/

/* Using a pointer to f, we are now passing by address!  Rather than a copy
 * of f, we now have the address of f!
 */
void populate_foo(struct foo *f)
{
  f->i = 42;
  f->f = 3.1415;

  printf("i = %d, f = %f\n", f->i, f->f);
}

// Incorrect - swaps the addresses in the pointers!
// We say that C has two parameter passing modes: pass by value and
// pass by address, but it actually only has pass by value!
/*
void swap(int *i, int *j)
{
  int *tmp;

  tmp = i;
  i = j;
  j = tmp;

  printf("%d %d\n", *i, *j);
}
*/

void swap(int *i, int *j)
{
  int tmp;

  // Unary * is the dereference operator.  It gives us the contents
  // of the memory addressed by the pointer to which it is applied.
  // * and & are opposites.
  tmp = *i;
  *i = *j;
  *j = tmp;
}

int main(int argc, char *argv[])
{
  struct foo f;
  int x, y;
  int *p;
  int i;
  
  x = 0;
  y = 1;

  p = &x;

  swap(&x, &y);
  printf("%d %d\n", x, y);

  printf("%d\n", *p);  // p is pointing at x.  *p is the contents of x.
                       // *p and x are aliases.

  p = malloc(sizeof (*p)); // sizeof is a static operator

  printf("%d\n", *p); // Error: *p hasn't been initialized

  *p = 5;
  printf("%d\n", *p);

  free(p);

  printf("%d\n", *p); // Error: The data addressed by p no longer belongs to
                      // this program.  Behavior is undefined.

  p = malloc(10 * sizeof (*p));

  for (i = 0; i < 10; i++) {
    p[i] = i; // Array syntax can be applied to pointers.
  }

  for (i = 0; i < 10; i++) {
    // "Pointer arithmetic": Adding an index to a pointer give the address of
    // the index's element.
    printf("%d\n", *(p + i));
  }

  free(p);
  
  f.i = 0;
  f.f = 0;

  printf("i = %d, f = %f\n", f.i, f.f);

  /* & is the address operator.  &f is the address of f (a pointer) */
  populate_foo(&f);

  printf("i = %d, f = %f\n", f.i, f.f);

  return 0;
}
