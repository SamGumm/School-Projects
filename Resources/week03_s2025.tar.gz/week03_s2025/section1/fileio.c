#include <stdio.h>
#include <math.h>  // Use -lm if calling function
#include <endian.h>

typedef enum {
  operation_rt,
  operation_wt,
  operation_rb,
  operation_wb
} operation;

void usage(const char *s)
{
  // Three files are opened by the runtime before main starts.  These are
  // stdin, stdout, stderr.
  fprintf(stderr, "Usage: %s [-rt|-wt|-rb|-wb]\n", s);
}

int main(int argc, char *argv[])
{
  operation op;
  int error;
  struct {
    int i;
    int j;
    double f;
  } in, out;
  FILE *f;
  int i;
  long long int d;
  
  error = 0;

  out.i = 1;
  out.j = 65537;
  out.f = M_PI;
  
  if (argc == 2 && argv[1][0] == '-') {
    if (argv[1][1] == 'r') {
      if (argv[1][2] == 't') {
        op = operation_rt;
      } else if (argv[1][2] == 'b') {
        op = operation_rb;
      } else {
        error = 1;
      }
    }
    if (argv[1][1] == 'w') {
      if (argv[1][2] == 't') {
        op = operation_wt;
      } else if (argv[1][2] == 'b') {
        op = operation_wb;
      } else {
        error = 1;
      }
    }
  } else {
    error = 1;
  }

  if (error) {
    usage(argv[0]);

    return -1;
  }

  switch (op) {
  case operation_wt:
    f = fopen("textfile", "w"); // Could fail to open.  Should check.
    fprintf(f, "%d\n%d\n%lf\n", out.i, out.j, out.f);
    break;
  case operation_rt:
    f = fopen("textfile", "r");
    fscanf(f, "%d\n%d\n%lf\n", &in.i, &in.j, &in.f);
    printf("%d\n%d\n%lf\n", in.i, in.j, in.f);
    break;
  case operation_wb:
    f = fopen("binaryfile", "wb"); // b is no-op outside of Windows
                                   // In Windows, it suppresses \r on \n
    i = htobe32(out.i);
    fwrite(&i, sizeof (i), 1, f); // Should return 1
    i = htobe32(out.j);
    fwrite(&i, sizeof (i), 1, f); // Should return 1
    // Don't worry about this part.  It's advanced, and you don't need
    // to do it or understand it.
    d = htobe64(*(long long int *) (&out.f));
    fwrite(&d, sizeof (d), 1, f); // Should return 1    
    break;
  case operation_rb:
    f = fopen("binaryfile", "rb");
    fread(&i, sizeof (i), 1, f);
    in.i = be32toh(i);
    fread(&i, sizeof (i), 1, f);
    in.j = be32toh(i);
    fread(&d, sizeof (d), 1, f);
    d = be64toh(d);
    in.f = *((double *) &d);
    printf("%d\n%d\n%lf\n", in.i, in.j, in.f);
    break;
  };

  fclose(f);
  
  return 0;
}
