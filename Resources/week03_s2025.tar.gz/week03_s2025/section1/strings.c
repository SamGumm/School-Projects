#include <stdio.h>

/*
  In C, strings are character arrays with a trailing (sentinel) NULL byte.
  The NULL byte marks the end of the string.  All string functions (in
  string.h) depend on this NULL byte to locate the end of the string.  If
  it is not there, either the array is intentionally not a string, or it
  is malformed.  In either case, treating it like a string is an error!

  To declare a string using a string literal:

  char a[] = "Foo"; // a is an array of length 4.  Index 3 is '\0'.
                    // The compiler copies the literal into the array.
  char *p = "Foo"; // p is a pointer to a string literal.  The literal
                   // is immutable!
 */

int strcmp3270(const char *s1, const char *s2)
{
  int i;

  for (i = 0; s1[i] && s2[i] && s1[i] == s2[i]; i++)
    ;
  
  return s1[i] - s2[i];
}

int strlen3270(const char *s)
{
  int i;

  for (i = 0; s[i]; i++)
    ;

  return i;
}

char *strcpy3270(char *dst, const char *src)
{
  int i;

  for (i = 0; src[i]; i++) {
    dst[i] = src[i];
  }
  dst[i] = '\0';

  return dst;
}

int main(int argc, char *argv[])
{
  char a[] = "Hello";
  char b[] = "Goodbye";
  char *c = "Hello";

  printf("%d\n%d\n", strcmp3270(a, b), strcmp3270(a, c));
  b[0] = 'H';
  printf("%d\n%d\n", strcmp3270(a, b), strcmp3270(a, c));
  //  c[0] = '\'';
  printf("%d\n%d\n", strcmp3270(a, b), strcmp3270(a, c));

  strcpy3270(b, c);
  printf("%s\n", b);
  printf("%s\n", b + strlen3270(b) + 1);
  
  return 0;
}
