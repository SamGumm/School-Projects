#include <stdio.h>
#include <math.h> // For M_PI.  If calling functions, must
                  // link with math library (-lm).
#include <endian.h>

typedef enum {
  operation_rt,
  operation_rb,
  operation_wt,
  operation_wb
} operation;

void usage(const char *s)
{
  // The runtime opens three files for us before main begins.
  // These are stdin, stdout, and stderr.
  fprintf(stderr, "%s [-rt|-rb|-wt|-wb]\n", s);
}

int main(int argc, char *argv[])
{
  operation op;
  int error;
  struct {
    int i;
    int j;
    double d;
  } in, out;
  FILE *f;
  int i;
  long long int d;
  
  //  (void) in; // Suppress unused error from compile.
  
  out.i = 1;
  out.j = 65537;
  out.d = M_PI;
  
  error = 1;
  if (argc == 2 && argv[1][0] == '-') {
    if (argv[1][1] == 'r') {
      if (argv[1][2] == 't') {
        op = operation_rt;
        error = 0;
      } else if (argv[1][2] == 'b') {
        op = operation_rb;
        error = 0;
      }
    } else if (argv[1][1] == 'w') {
      if (argv[1][2] == 't') {
        op = operation_wt;
        error = 0;
      } else if (argv[1][2] == 'b') {
        op = operation_wb;
        error = 0;
      }
    }
  }
  
  if (error) {
    usage(argv[0]);

    return -1;
  }

  switch (op) {
  case operation_rt:
    f = fopen("textfile", "r");
    fscanf(f, "%d\n%d\n%lf\n", &in.i, &in.j, &in.d);
    printf("%d\n%d\n%lf\n", in.i, in.j, in.d);
    break;
  case operation_wt:
    f = fopen("textfile", "w"); // Can fail.  Should check.
    fprintf(f, "%d\n%d\n%lf\n", out.i, out.j, out.d);
    break;
  case operation_rb:
    f = fopen("binaryfile", "rb");
    fread(&i, sizeof (i), 1, f);
    in.i = be32toh(i);
    fread(&i, sizeof (i), 1, f);
    in.j = be32toh(i);
    fread(&d, sizeof (d), 1, f);
    d = be64toh(d);
    in.d = *(double *) &d;
    printf("%d\n%d\n%lf\n", in.i, in.j, in.d);
    break;
  case operation_wb:
    f = fopen("binaryfile", "wb"); // b tells Windows to suppress \r
                                   // ignored in all other environs.
    i = htobe32(out.i);
    fwrite(&i, sizeof (i), 1, f); // Should return 1.  Should check!
    i = htobe32(out.j);
    fwrite(&i, sizeof (i), 1, f); // Should return 1.  Should check!
    d = htobe64(*(long long int *) &out.d);
    fwrite(&d, sizeof (d), 1, f); // Should return 1.  Should check!
    break;
  }

  fclose(f);
  
  return 0;
}
