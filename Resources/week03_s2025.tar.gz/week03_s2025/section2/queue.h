#ifndef QUEUE_H
#define QUEUE_H

typedef struct queue_node queue_node;

struct queue_node {
  queue_node *next;
  int data;
};

//typedef extant_type new_name;

typedef struct queue {
  queue_node *front, *back;
  int length;
} queue;

int queue_init(queue *q);
int queue_destroy(queue *q);
int queue_enqueue(queue *q, int value);
int queue_dequeue(queue *q, int *value);
int queue_front(queue *q, int *value);
int queue_length(queue *q);
int queue_is_empty(queue *q);

#endif
