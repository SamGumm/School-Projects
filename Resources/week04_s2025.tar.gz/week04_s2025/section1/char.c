#include <stdio.h>
#include <ctype.h>

char *words[] = {
  "apple",
  "banana",
  "cat",
  "dinosaur",
  "elephant",
  "faith",
  "giraffe",
  "honda",
  "igloo",
  "joker",
  "kit-kat",
  "lion",
  "mazda",
  "nissan",
  "opal",
  "prius",
  "quarter",
  "ranger",
  "subaru",
  "tense",
  "utopia",
  "vocal",
  "window",
  "xylephone",
  "yo-yo",
  "zebra",
};

int main(int argc, char *argv[])
{
  char c;

  c = argv[1][0];
  
  printf("%c is for %s\n", c, words[tolower(c) - 'a']);
}
