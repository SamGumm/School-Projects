#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* When reading declarations in C, we start at the name and go *
 * right when we can and left when we must.                    */

int compare_int(void *i1, void *i2)
{
  return *((int *) i1) - *((int *) i2);
}

int compare_int_reverse(void *i1, void *i2)
{
  return *((int *) i2) - *((int *) i1);
}

int compare_char(void *i1, void *i2)
{
  return *((char *) i1) - *((char *) i2);
}

void insertion_sort_int(int *a, int n)
{
  int i, j, t;
  
  for (i = 1; i < n; i++) {
    for (t = a[i], j = i - 1; j > -1 && a[j] > t; j--) {
      a[j + 1] = a[j];
    }
    a[j + 1] = t;
  }
}

// Final parameter is pointer to function taking two void pointers
// and returning int.  size is size of each element in a.
void insertion_sort_generic(void *a, int n, int size,
                            int (*compare)(void *, void *))
{
  int i, j;
  void *t;
  // Use a pointer to char so that we can have byte addressing
  char *c = a;

  t = malloc(size);

  for (i = 1; i < n; i++) {
    for (memcpy(t, c + (i * size), size), j = i - 1;
         j > -1 && compare(c + (j * size), t) > 0;
         j--) {
      memcpy(c + ((j + 1) * size), c + (j * size), size);
    }
    memcpy(c + ((j + 1) * size), t, size);
  }

  free(t);
}

/*
  int *i;

  i[4] --compiler replaces with--> i + 4 * sizeof (int)
  But, if we want to do the pointer arithmetic by hand, we don't
  need the multiplication!
  &i[4] == i + 4

  Since chars are 1 byte, we need to use chars (or some other 1-byte
  type) in order to force byte addressing.  Compiler will implicitly
  multiply by 1.
*/

int a[] = {
  10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0
};

char *words[] = {
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "ten",
};

int compare_strings(void *s1, void *s2)
{
  return strcmp(*(char **) s1, *(char **) s2);
}

int main(int argc, char *argv[])
{
  int i;
  char s[] = "the quick brown fox jumps over the lazy dog.";
  
  insertion_sort_generic(a, sizeof (a) / sizeof (a[0]),
                         sizeof (*a), compare_int);

  for (i = 0; i < sizeof (a) / sizeof (*a); i++) {
    printf("%d ", a[i]);
  }
  printf("\n");
  
  insertion_sort_generic(a, sizeof (a) / sizeof (*a),
                         sizeof (*a), compare_int_reverse);

  for (i = 0; i < sizeof (a) / sizeof (*a); i++) {
    printf("%d ", a[i]);
  }
  printf("\n");

  printf("%s\n", s);
  insertion_sort_generic(s, strlen(s), 1, compare_char);
  printf("%s\n", s);

  for (i = 0; i < sizeof (words) / sizeof (words[0]); i++) {
    printf("%s\n", words[i]);
  }
  printf("\n");
  insertion_sort_generic(words, sizeof (words) / sizeof (words[0]),
                         sizeof (words[0]),
                         compare_strings);
  for (i = 0; i < sizeof (words) / sizeof (words[0]); i++) {
    printf("%s\n", words[i]);
  }
  
  return 0;
}
