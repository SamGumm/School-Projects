#ifndef DARRAY_H
#define DARRAY_H

struct darray;
typedef struct darray darray;

int darray_init(darray **d, unsigned element_size);
int darray_destroy(darray *d);
int darray_add(darray *d, void *v);
int darray_at(darray *d, unsigned i, void *v);
int darray_remove(darray *d, unsigned i); // Removes ith element, maintaining order
int darray_length(darray *d);

#endif
