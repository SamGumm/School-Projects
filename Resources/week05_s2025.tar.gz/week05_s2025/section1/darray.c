#include <stdlib.h>
#include <string.h>

#include "darray.h"

#define DEFAULT_DARRAY_SIZE 10

struct darray {
  char *a;               // The array
  unsigned element_size; // The size of the data
  unsigned length;       // The number of elements in the array
  unsigned capacity;     // Number of elements allocated
};

static int darray_resize(darray *d)
{
  char *tmp;
  
  if (!(tmp = realloc(d->a, 2 * d->capacity * d->element_size))) {
    return -1;
  }

  d->capacity *= 2;
  d->a = tmp;

  return 0;
}

int darray_init(darray **d, unsigned element_size)
{
  if (!(*d = malloc(sizeof (**d))) ||
      !((*d)->a = malloc(element_size * DEFAULT_DARRAY_SIZE))) {
    return -1;
  }
  
  (*d)->element_size = element_size;
  (*d)->length = 0;
  (*d)->capacity = DEFAULT_DARRAY_SIZE;

  return 0;
}

int darray_destroy(darray *d)
{
  free(d->a);
  free(d);

  return 0;
}

int darray_add(darray *d, void *v)
{
  if (d->capacity == d->length) {
    if (darray_resize(d)) {
      return -1;
    }
  }

  // Insert v at index length
  memcpy(d->a + (d->element_size * d->length), v, d->element_size);
  d->length++;

  return 0;
}

int darray_at(darray *d, unsigned i, void *v)
{
  if (i >= d->length) {
    return -1;
  }

  memcpy(v, d->a + (d->element_size * i), d->element_size);

  return 0;
}

int darray_remove(darray *d, unsigned i)
{
  if (i >= d->length) {
    return -1;
  }

  memmove(d->a + (d->element_size * i),              // Use memmove because src and dst overlap
          d->a + (d->element_size * (i + 1)),        // Error to use memcpy here
          (d->length - i - 1) * d->element_size);

  d->length--;
  
  return 0;
}

int darray_length(darray *d)
{
  return d->length;
}

