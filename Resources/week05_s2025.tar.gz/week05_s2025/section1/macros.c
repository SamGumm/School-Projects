// #include <stdio.h>

// Header guards
#ifndef MACROS_H
#define MACROS_H

#endif

// Value-type macros
#define DARRAY_DEFAULT_CAPACITY 10

// Function-type macro
#define min(x, y) (x < y ? x : y)


int main(int argc, char *argv[])
{
  printf("%d\n", DARRAY_DEFAULT_CAPACITY); // Macro replacement
                                           // Macro is replaced by its value
  printf("The min of a and b is: %d", min(a, b));

  // min(a, b) = 10;

  min(function_with_side_effect(), very_expensive_function());

  return 0;
}
