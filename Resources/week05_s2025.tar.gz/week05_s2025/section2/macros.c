// #include <stdio.h>

// Value-type macros
#define DARRAY_DEFAULT_CAPACITY 10

int main(int argc, char *argv[])
{
  printf("%d\n", DARRAY_DEFAULT_CAPACITY);

  return 0;
}
