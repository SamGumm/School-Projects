// #include <stdio.h>

// Header guards
#ifndef MACROS_H
#define MACROS_H

#endif

// Value-type macros
#define DARRAY_DEFAULT_CAPACITY 10

// Function-type macro
#define min(x, y) (x < y ? x : y)

// The value of a basic block is the value value of its final expression
// (the last line).  But, basic blocks aren't expressions!  However, if
// we wrap it in parenthesis, then it becomes an expression!
#define max(x, y) ({   \
  typeof (x) _x = (x); \
  typeof (y) _y = (y); \
  _x > _y ? _x : _y;   \
})

#define stringify(x) #x

#define concatenate(x) x ## _foo


// I think the most useful thing you can do with stringification is build
// lookup tables with little chance of error.

int monster_foo(int x);
int monster_bar(int x);
int monster_baz(int x);
//...

typedef int (*fptr)(int);

struct lu_entry {
  const char *name;
  fptr func;
};

#define lookup_table_entry(name) { #name, monster_ ## name }

struct lu_entry lu_table[] = {
  //  { "foo", foo },
  //  { "bar", bar },...
  lookup_table_entry(bar),
  lookup_table_entry(baz),
  lookup_table_entry(foo),
  //...
  lookup_table_entry(zap),
};

#define log(...) fprintf(log_file, __VA_ARGS__)

int main(int argc, char *argv[])
{
  printf("%d\n", DARRAY_DEFAULT_CAPACITY); // Macro replacement
                                           // Macro is replaced by its value
  printf("The min of a and b is: %d", min(a, b));

  // min(a, b) = 10;

  min(function_with_side_effect(), very_expensive_function());

  max(function_with_side_effect(), very_expensive_function());

  stringify(foo);

  // We can lookup and call the function in a single line of code.
  bsearch("foo", num_function, sizeof (an entry), comparitor)->func(x);

  concatenate(bar);

  log("System error: file %s does not exist", f, g, h, i);
  
  return 0;
}
