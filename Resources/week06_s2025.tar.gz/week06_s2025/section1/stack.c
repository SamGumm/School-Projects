#include <stdlib.h>

#include "stack.h"

/*
stack s;
stack_init(&s);

stack *sp;
sp = malloc(sizeof (*sp));
stack_init(sp);
*/

int stack_init(stack *s)
{
  s->top = NULL;
  s->size = 0;

  return 0;
}

int stack_destroy(stack *s)
{
  /* This is valid, but not performant.
  int tmp;
  
  while (!stack_pop(s, &tmp))
    ;

  return 0;
  */

  stack_node *tmp;

  while ((tmp = s->top)) {
    s->top = s->top->next;
    free(tmp);
  }

  s->size = 0;

  return 0;
}

int stack_push(stack *s, int value)
{
  stack_node *tmp;

  if (!(tmp = malloc(sizeof (*tmp)))) {
    // Returned NULL.  Malloc failed.
    return -1;
  }
  
  tmp->next = s->top;
  s->top = tmp;
  tmp->data = value;

  s->size++;

  return 0; // Success
}

int stack_pop(stack *s, int *value)
{
  stack_node *tmp;
  
  if (!s->size) {
    return -1;
  }

  *value = s->top->data;
  tmp = s->top;
  s->top = s->top->next;

  free(tmp);

  s->size--;

  return 0;
}

int stack_top(stack *s, int *value)
{
  if (!s->top) {
    return -1;
  }

  *value = s->top->data;

  return 0;
}

int stack_is_empty(stack *s)
{
  return !s->size;
}

int stack_size(stack *s)
{
  return s->size;
}
