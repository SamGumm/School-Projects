#ifndef STACK_H
#define STACK_H

typedef struct stack_node stack_node; // typedefing a forward reference

struct stack_node {
  stack_node *next;
  int data;
};

// typedef extant_type new_name;

typedef struct stack {
  stack_node *top;
  int size;
} stack;

int stack_init(stack *s);
int stack_destroy(stack *s);
int stack_push(stack *s, int value);
int stack_pop(stack *s, int *value);
int stack_top(stack *s, int *value);
int stack_is_empty(stack *s);
int stack_size(stack *s);

#endif
