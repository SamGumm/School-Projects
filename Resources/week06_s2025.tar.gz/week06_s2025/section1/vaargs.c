#include <stdio.h>
#include <stdarg.h>

/* This is a very stripped down printf.  It does 4 kinds of conversions:
 * It can print ints, floats, chars, and strings.  It will not use %,  
 * it will not allow modifiers (like field width) to conversion specifiers,
 * and it will not allow any characters in the format string except for
 * the conversion specifiers.
 */
void printf3270(const char *format, ...)
{
  va_list ap;

  va_start(ap, format);

  while (*format) {
    switch (*format) {
    case 'd':
      printf("%d\t", va_arg(ap, int));
      break;
    case 'f':
      printf("%f\t", va_arg(ap, double));
      break;
    case 'c':
      printf("%c\t", va_arg(ap, int));
      break;
    case 's':
      printf("'%s'\t", va_arg(ap, char *));
      break;
    }
    format++;
  }
  printf("\n");

  va_end(ap);
}

int main(int argc, char *argv[])
{
  printf3270("dsccf", 3, "Hello World!", 'f', 96, 3.14159);
  return 0;
}
