// #include <stdio.h>

// Value-type macros
#define DARRAY_DEFAULT_CAPACITY 10

// Function-type macros
#define min(x, y) (x < y ? x : y)

// Curly braces enclose "basic blocks".  Basic blocks contain a scope.
// Variables declared within a basic block go out of scope at the end
// of the block.
// Basic blocks have a value.  Their value is the value of their last
// line.  However, basic blocks are not expressions!  The trick is to
// wrap the BB in parenthesis, which transforms it into an expression.
#define max(x, y) ({   \
  typeof (x) _x = (x); \
  typeof (y) _y = (y); \
  _x > _y ? _x : _y;   \
})

#define stringify(x) #x

#define concatenate(x) cmd_ ## x

int cmd_foo(int);
int cmd_bar(int);
int cmd_baz(int);
//...
int cmd_zip(int);

typedef int (*fptr)(int);

struct lu_entry {
  const char *name;
  fptr func;
};

#define lu_value(name) { #name, cmd_ ## name }

struct lu_entry table[] = {
  lu_value(bar),
  lu_value(baz),
  lu_value(foo),
  // ...
  lu_value(zip),
};

#define LOG(...) fprintf(log, __VA_ARGS__)

int main(int argc, char *argv[])
{
  printf("%d\n", DARRAY_DEFAULT_CAPACITY);

  min(a, b);
  min(function_with_side_effects(), very_expensive_function());
  max(function_with_side_effects(), very_expensive_function());

  stringify(foo);

  bsearch(key, table, number of elements, sizeof element, comparitor)->func(0);

  concatenate(foo);

  LOG("Error in %s\n", file, f, g, h);
  
  return 0;
}
