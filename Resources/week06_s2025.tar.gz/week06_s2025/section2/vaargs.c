#include <stdio.h>
#include <stdarg.h>

// This is an extremely watered-down printf.  It prints ints, float, chars
// and strings.  We will not expect % before conversion specifiers.  We
// will not print the contents of format strings.  We will not support
// modifiers to conversions.
void printf3270(const char *format, ...)
{
  va_list ap;

  va_start(ap, format);
  
  while (*format) {
    switch (*format) {
    case 'd':
      printf("%d\t", va_arg(ap, int));
      break;
    case 's':
      printf("'%s'\t", va_arg(ap, char *));
      break;
    case 'c':
      printf("%c\t", va_arg(ap, int));
      break;
    case 'f':
      printf("%f\t", va_arg(ap, double));
      break;
    }
    format++;
  }
  printf("\n");

  va_end(ap);
}

int main(int argc, char *argv[])
{
  printf3270("dscf", 189, "Hello World!", 't', 1.616);
  
  return 0;
}
